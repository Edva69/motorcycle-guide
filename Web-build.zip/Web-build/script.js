// Initialize feedback from localStorage
const storedFeedback = JSON.parse(localStorage.getItem('feedback') || '[]');

// Simple profanity filter - can be expanded
const bannedWords = [
  'fuck', 'shit', 'ass', 'bitch', 'nigger', 'faggot',
  // Add more banned words as needed
];

function containsBannedWords(text) {
  const lowerText = text.toLowerCase();
  return bannedWords.some(word => lowerText.includes(word));
}

function submitFeedback() {
  const feedbackText = document.getElementById('feedbackText').value.trim();
  
  if (!feedbackText) {
    alert('Please enter some feedback before submitting.');
    return;
  }

  if (containsBannedWords(feedbackText)) {
    alert('Please keep your feedback clean and respectful.');
    return;
  }

  // Save feedback to localStorage
  const feedback = JSON.parse(localStorage.getItem('feedback') || '[]');
  feedback.unshift({
    content: feedbackText,
    timestamp: new Date().toISOString()
  });
  localStorage.setItem('feedback', JSON.stringify(feedback));
  
  // Update display
  const feedbackList = document.getElementById('feedbackList');
  feedbackList.innerHTML = '';
  
  feedback.forEach(item => {
    const feedbackElement = document.createElement('div');
    feedbackElement.style.padding = '10px';
    feedbackElement.style.marginTop = '10px';
    feedbackElement.style.backgroundColor = 'white';
    feedbackElement.style.borderRadius = '5px';
    
    const timestamp = new Date(item.timestamp).toLocaleString();
    feedbackElement.innerHTML = `
      <p style="margin: 0;"><strong>Anonymous</strong> - ${timestamp}</p>
      <p style="margin: 5px 0 0 0;">${item.content}</p>
    `;
    
    feedbackList.appendChild(feedbackElement);
  });
  
  // Clear the input
  document.getElementById('feedbackText').value = '';
}

function showCCInfo() {
  const select = document.getElementById('ccRange');
  const infoDiv = document.getElementById('ccInfo');
  
  const ccInfo = {
    "0": `Small engines (50-150cc): Perfect for beginners. These bikes are lightweight, fuel-efficient, and easy to handle. Common examples: Honda Grom, scooters. Groms and scooters are usually meant to be rode around in cities/towns and cant go on a highway therefore it doesnt have enough power to keep up with cars so it will cause traffic and they are also illegal to go on highways because of this. <br><br><a href="https://en.wikipedia.org/wiki/Honda_Grom" target="_blank" style="color: blue; text-decoration: underline;">Click here for more information about Honda Grom</a>`,
  
    "1": `Mid-small engines (125-250cc): Great for daily commuting and some highway riding. Offers better performance while maintaining good fuel economy. Popular model: kawasaki ninja 250 this type of bike has enough power to keep up with other cars and keep traffic flowing.<br><br><a href="https://www.bestbeginnermotorcycles.com/kawasaki-ninja-250-review/" target="_blank" style="color: blue; text-decoration: underline;">Click here for Kawasaki Ninja 250 Review</a>`,
 
    "2": `Mid-range engines (250-500cc): Versatile bikes suitable for both city and highway riding. Good balance of power and control. Example: KTM Duke 390.<br><br><a href="https://www.bikedekho.com/ktm/duke-390/specifications" target="_blank" style="color: blue; text-decoration: underline;">Click here for KTM Duke 390 Specifications</a>`,
   
    "3": `Large engines (500-1800cc): High-performance bikes for experienced riders. Ideal for long-distance touring and high-speed riding. Example: BMW R1250GS.<br><br><a href="https://www.bmw-motorrad.ie/en/models/adventure/r1250gsadventure.html" target="_blank" style="color: blue; text-decoration: underline;">Click here for BMW R1250GS Details</a>`
  };

  infoDiv.style.display = 'block';
  infoDiv.innerHTML = ccInfo[select.value];
}

